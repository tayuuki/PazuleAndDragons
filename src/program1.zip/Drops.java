
public class Drops {
	int x, y, r, index, indey, c;
	int[][] matrix;
	
	public Drops(int x, int y, int r, int index, int indey, int c) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.index = index;
		this.indey = indey;
		this.c = c;
		// this.matrix = matrix;
	}

	public void draw(MyFrame2 frame) {

	}
}
