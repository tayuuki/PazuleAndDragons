
public class Monster {
	int x, y, w, h, HP, hp;
	public Monster(int x, int y, int w, int h, int HP, int hp) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.HP = HP;
		this.hp = hp;
	}
	
	public void draw(MyFrame2 frame) {
		
	}
}
